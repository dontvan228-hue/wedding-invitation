
let isBookOpened = false;
let isEditMode = true;
let rsvpResponses = JSON.parse(localStorage.getItem('wedding_rsvp_v2') || '[]');

const templatesCatalogData = [
  { id: 'gold', name: 'Шёлковая классика', palette: ['#FAF8F5','#C5A059','#1F1D1A'], desc: 'Теплый айвори и золото.' },
  { id: 'tatar', name: 'Татарский Никах', palette: ['#F0F7F7','#0D9488','#0F2B30'], desc: 'Священный Никах и бирюзовые мотивы.' },
  { id: 'uzbek', name: 'Узбекский Никох', palette: ['#0A192F','#F59E0B','#F8FAFC'], desc: 'Восточный дастархан и золото.' },
  { id: 'gothic', name: 'Готика & Dark Romance', palette: ['#09090B','#DC2626','#27272A'], desc: 'Темный бархат и рубиновые розы.' }
];

let config = JSON.parse(localStorage.getItem('wedding_config_v2') || JSON.stringify({
  p1: 'Александр', p2: 'Екатерина', venue: 'Усадьба «Вилла Ротонда»', theme: 'gold', font: 'serif',
  timelineSteps: [
    { t: '15:30', n: 'Сбор гостей & Welcome 🥂', d: 'Приветственные напитки.' },
    { t: '16:30', n: 'Церемония 💍', d: 'Обмен клятвами.' },
    { t: '17:30', n: 'Банкет 🍽️', d: 'Праздничный ужин.' }
  ]
}));

window.addEventListener('DOMContentLoaded', () => {
  const params = new URLSearchParams(window.location.search);
  if (params.get('guest') === '1' || window.location.hash.startsWith('#data=')) {
    document.body.classList.add('guest-mode');
    document.body.classList.remove('edit-mode');
    isEditMode = false;
  }
  renderAll();
  startCountdown();
});

function saveState() {
  localStorage.setItem('wedding_config_v2', JSON.stringify(config));
  renderAll();
}

function renderAll() {
  document.getElementById('dispP1').textContent = config.p1;
  document.getElementById('dispP2').textContent = config.p2;
  document.getElementById('footerP1').textContent = config.p1;
  document.getElementById('footerP2').textContent = config.p2;
  document.getElementById('dispBookNames').textContent = `${config.p1} & ${config.p2}`;
  document.getElementById('dispCoverNames').textContent = `${config.p1} & ${config.p2}`;
  document.getElementById('dispVenue').textContent = config.venue;
  document.body.setAttribute('data-theme', config.theme || 'gold');
  document.body.setAttribute('data-font', config.font || 'serif');
  renderTimeline();
}

function animateOpenEntrance() {
  const overlay = document.getElementById('introBookOverlay');
  if (overlay) {
    overlay.classList.add('opened');
    setTimeout(() => overlay.classList.add('hidden'), 900);
  }
}

function copyGuestShareLink() {
  const json = encodeURIComponent(btoa(unescape(encodeURIComponent(JSON.stringify(config)))));
  const url = window.location.origin + window.location.pathname + '?guest=1#data=' + json;
  if (navigator.clipboard) navigator.clipboard.writeText(url);
  toast('✓ Гостевая ссылка скопирована!');
  closeShareModal();
}

function renderTimeline() {
  const cont = document.getElementById('timelineListContainer');
  if (!cont) return;
  cont.innerHTML = '';
  config.timelineSteps.forEach((s, idx) => {
    const item = document.createElement('div');
    item.className = 'timeline-item';
    item.innerHTML = `
      <div class="timeline-dot">${idx + 1}</div>
      <div class="timeline-time">${s.t}</div>
      <div class="timeline-title font-title">${s.n}</div>
      <div class="timeline-desc">${s.d}</div>
    `;
    cont.appendChild(item);
  });
}

function sendRsvp(e) {
  e.preventDefault();
  const name = document.getElementById('rsvpName').value.trim();
  const status = document.querySelector('input[name="rsvpStatus"]:checked').value;
  const food = document.querySelector('input[name="rsvpFood"]:checked').value;
  
  rsvpResponses.push({ name, status, food, time: new Date().toLocaleDateString() });
  localStorage.setItem('wedding_rsvp_v2', JSON.stringify(rsvpResponses));
  toast('✓ Спасибо! Ответ отправлен.');
  e.target.reset();
}

function openUserCabinetModal() {
  document.getElementById('cabinetModal').classList.add('active');
  const list = document.getElementById('cabinetRsvpList');
  document.getElementById('cabinetRsvpTitle').textContent = `💌 Полученные ответы гостей (${rsvpResponses.length})`;
  if (rsvpResponses.length === 0) {
    list.innerHTML = '<div style="color:#a0aec0;">Пока нет ответов.</div>';
    return;
  }
  list.innerHTML = rsvpResponses.map((r, i) => `<div>${i+1}. <b>${r.name}</b> — ${r.status} (${r.food})</div>`).join('');
}
function closeUserCabinetModal() { document.getElementById('cabinetModal').classList.remove('active'); }

function openTemplatesCatalog() {
  const grid = document.getElementById('templatesGridContainer');
  grid.innerHTML = templatesCatalogData.map(t => `
    <div class="tpl-card">
      <div class="tpl-preview-header" style="background:${t.palette[0]}; border-bottom:1px solid #e2e8f0;">
        <span style="font-weight:700; color:${t.palette[1]};">${t.name}</span>
      </div>
      <div class="tpl-body">
        <p style="font-size:0.85rem; color:#718096; margin-bottom:1rem;">${t.desc}</p>
        <button type="button" class="btn-action" style="width:100%; margin:0; padding:0.5rem;" onclick="selectTemplate('${t.id}')">Выбрать</button>
      </div>
    </div>
  `).join('');
  document.getElementById('templatesCatalogModal').classList.add('active');
}
function closeTemplatesCatalog() { document.getElementById('templatesCatalogModal').classList.remove('active'); }
function selectTemplate(id) {
  config.theme = id;
  saveState();
  closeTemplatesCatalog();
  toast('✓ Шаблон применен!');
}

let audioCtx = null;
let isPlaying = false;
let musicTimer = null;
function toggleWeddingMusic() {
  isPlaying = !isPlaying;
  const waves = document.getElementById('musicWaves');
  if (isPlaying) {
    waves.style.display = 'inline-flex';
    playNote();
    musicTimer = setInterval(playNote, 3500);
    toast('🎵 Музыка включена');
  } else {
    waves.style.display = 'none';
    if (musicTimer) clearInterval(musicTimer);
    toast('Музыка остановлена');
  }
}
function playNote() {
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.frequency.setValueAtTime(523.25, audioCtx.currentTime);
    gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 1.5);
    osc.connect(gain); gain.connect(audioCtx.destination);
    osc.start(); osc.stop(audioCtx.currentTime + 1.6);
  } catch(e) {}
}

function startCountdown() {
  setInterval(() => {
    const diff = new Date('2027-06-19T16:30:00').getTime() - new Date().getTime();
    if (diff > 0) {
      document.getElementById('cdDays').textContent = Math.floor(diff / (1000*60*60*24));
      document.getElementById('cdHours').textContent = Math.floor((diff / (1000*60*60)) % 24);
      document.getElementById('cdMinutes').textContent = Math.floor((diff / (1000*60)) % 60);
      document.getElementById('cdSeconds').textContent = Math.floor((diff / 1000) % 60);
    }
  }, 1000);
}

function toggleAiChat() { document.getElementById('aiChatWindow').classList.toggle('active'); }
function askAiPrompt(topic) {
  const box = document.getElementById('aiResponseBox');
  box.style.display = 'block';
  if (topic === 'tatar') { config.theme = 'tatar'; saveState(); box.innerHTML = '✓ Стиль <b>Татарский Никах</b> применен!'; }
  else if (topic === 'uzbek') { config.theme = 'uzbek'; saveState(); box.innerHTML = '✓ Стиль <b>Узбекский Никох туй</b> применен!'; }
  else if (topic === 'gothic') { config.theme = 'gothic'; saveState(); box.innerHTML = '✓ Стиль <b>Готика</b> применен!'; }
}
function sendCustomAiQuery() {
  const inp = document.getElementById('inpAiQuery');
  if (!inp.value.trim()) return;
  const box = document.getElementById('aiResponseBox');
  box.style.display = 'block';
  box.innerHTML = `✨ ИИ обработал запрос. Всё настроено!`;
  inp.value = '';
}

function toggleSidebarEditor() { document.getElementById('sidebarEditorDrawer').classList.toggle('open'); }
function switchSidebarTab(tab, btn) {
  document.querySelectorAll('.sidebar-nav-pill').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.sidebar-section-tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('sbTab_' + tab).classList.add('active');
}
function liveUpdateP1(val) { config.p1 = val; saveState(); }
function liveUpdateP2(val) { config.p2 = val; saveState(); }
function liveUpdateVenue(val) { config.venue = val; saveState(); }

function openStudio() { document.getElementById('studioModal').classList.add('active'); }
function closeStudio() { document.getElementById('studioModal').classList.remove('active'); }
function selectThemeWithCheck(th) { config.theme = th; saveState(); closeStudio(); toast('✓ Тема обновлена!'); }
function openShareModal() { document.getElementById('shareModal').classList.add('active'); }
function closeShareModal() { document.getElementById('shareModal').classList.remove('active'); }
function toggleDesktopViewMode() { document.body.classList.toggle('phone-frame-mode'); toast('Вид изменен'); }
function toggleEditMode() {
  isEditMode = !isEditMode;
  document.body.classList.toggle('edit-mode', isEditMode);
  toast(isEditMode ? 'Режим правки' : 'Режим просмотра');
}
function deleteBlockPermanently(btn) { btn.closest('.card-block').remove(); toast('Блок удален'); }
function copyCard() { navigator.clipboard.writeText('4276123456789012'); toast('✓ Номер карты скопирован'); }
function downloadIcs() { toast('✓ Календарь скачан'); }
function addToGoogleCalendar() { window.open('https://calendar.google.com', '_blank'); }
function copyInviteLink() { navigator.clipboard.writeText(window.location.href); toast('✓ Ссылка скопирована'); closeShareModal(); }
function toast(msg) {
  const t = document.getElementById('toast');
  t.querySelector('span').textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 3000);
}
